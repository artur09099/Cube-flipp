package com.example.cubeflip;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.MotionEvent;
import android.animation.ValueAnimator;
import android.view.animation.DecelerateInterpolator;
import android.graphics.*;
import java.util.*;

public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b) {
  super.onCreate(b);
  getWindow().setStatusBarColor(Color.rgb(20,20,20));
  getWindow().setNavigationBarColor(Color.rgb(20,20,20));
  setContentView(new CubeView());
 }
 class CubeView extends View {
  Paint p=new Paint(3); float angle=0f, tilt=-0.22f; boolean busy=false;
  Random random=new Random(); float size; int bg=Color.rgb(20,20,20);
  float[][] v={{-1,-1,-1},{1,-1,-1},{1,1,-1},{-1,1,-1},{-1,-1,1},{1,-1,1},{1,1,1},{-1,1,1}};
  int[][] faces={{4,5,6,7},{1,0,3,2},{0,4,7,3},{5,1,2,6},{3,7,6,2},{0,1,5,4}};
  CubeView(){super(MainActivity.this);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
  @Override protected void onDraw(Canvas c){
   super.onDraw(c); c.drawColor(bg);
   float cx=getWidth()/2f,cy=getHeight()/2f; size=Math.min(getWidth(),getHeight())*.235f;
   float[][] pts=new float[8][3]; double ca=Math.cos(angle),sa=Math.sin(angle),ct=Math.cos(tilt),st=Math.sin(tilt);
   for(int i=0;i<8;i++){double x=v[i][0],y=v[i][1],z=v[i][2]; double xr=x*ca-z*sa,zr=x*sa+z*ca,yr=y*ct-zr*st,zz=y*st+zr*ct;pts[i][0]=(float)xr;pts[i][1]=(float)yr;pts[i][2]=(float)zz;}
   Integer[] order={0,1,2,3,4,5}; Arrays.sort(order,(a,b)->Float.compare(depth(pts,faces[a]),depth(pts,faces[b])));
   for(int fi:order){int[] f=faces[fi];Path path=new Path();for(int j=0;j<4;j++){float[] q=project(pts[f[j]],cx,cy);if(j==0)path.moveTo(q[0],q[1]);else path.lineTo(q[0],q[1]);}path.close();
    float d=depth(pts,f);int color=fi==0?Color.rgb(155,155,155):fi==1?Color.WHITE:Color.rgb(125,125,125);color=shade(color,Math.max(.58f,Math.min(1.12f,.88f+d*.10f)));
    p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawPath(path,p);p.setColor(Color.argb(45,0,0,0));p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2f);c.drawPath(path,p);p.setStyle(Paint.Style.FILL);
   }
   p.setColor(Color.argb(24,255,255,255));p.setTextAlign(Paint.Align.CENTER);p.setTextSize(14f);c.drawText("НАЖМИ НА КУБИК",cx,cy+size*2.05f,p);
  }
  float depth(float[][] pts,int[] f){float d=0;for(int i:f)d+=pts[i][2];return d/4f;}
  float[] project(float[] q,float cx,float cy){float k=3.8f/(3.8f-q[2]*.35f);return new float[]{cx+q[0]*size*k,cy+q[1]*size*k};}
  int shade(int c,float k){return Color.rgb(Math.min(255,(int)(Color.red(c)*k)),Math.min(255,(int)(Color.green(c)*k)),Math.min(255,(int)(Color.blue(c)*k)));}
  @Override public boolean onTouchEvent(MotionEvent e){
   if(e.getAction()==MotionEvent.ACTION_UP&&!busy){float start=angle;boolean white=random.nextBoolean();float turns=(3+random.nextInt(3))*((float)Math.PI*2);ValueAnimator a=ValueAnimator.ofFloat(start,start+turns+(white?(float)Math.PI:0f));a.setDuration(850);a.setInterpolator(new DecelerateInterpolator());a.addUpdateListener(x->{angle=(float)x.getAnimatedValue();invalidate();});a.addListener(new android.animation.AnimatorListenerAdapter(){@Override public void onAnimationStart(android.animation.Animator animation){busy=true;}@Override public void onAnimationEnd(android.animation.Animator animation){busy=false;}});a.start();performClick();return true;}return true;
  }
  @Override public boolean performClick(){super.performClick();return true;}
 }
}
